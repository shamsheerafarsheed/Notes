package ArrayDemo;

import java.util.Scanner;

public class MarksAnalysis {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
	        int[] marks = new int[5];
	        int sum = 0, highest = 0;

	        System.out.println("Enter marks of 5 students:");
	        for (int i = 0; i < 5; i++) {
	            marks[i] = sc.nextInt();
	            sum += marks[i];
	            if (marks[i] > highest) highest = marks[i];
	        }

	        double avg = (double) sum / marks.length;
	        int countAboveAvg = 0;
	        for (int m : marks) {
	            if (m > avg) countAboveAvg++;
	        }

	        System.out.println("Average: " + avg);
	        System.out.println("Highest: " + highest);
	        System.out.println("Above Average Count: " + countAboveAvg);
	    }
	

	
}
