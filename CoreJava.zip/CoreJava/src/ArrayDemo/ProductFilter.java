package ArrayDemo;

public class ProductFilter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] prices = {250, 800, 450, 1200, 600};
        int min = prices[0], max = prices[0];

        System.out.println("Products priced above ₹500:");
        for (int price : prices) {
            if (price > 500) 
            	System.out.println("₹" + price);
            if (price < min) 
            	min = price;
            if (price > max)
            	max = price;
        }

        System.out.println("Cheapest product: ₹" + min);
        System.out.println("Costliest product: ₹" + max);

	}

}
