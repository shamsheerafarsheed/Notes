package inheritanceDemo;
class Human
{
	String name;
	void display()
	{
		System.out.println("I am a human being:");
	}
	void eats()
	{
		
	}
}
class Male extends HumanDemo
{
	void eats()
	{
		System.out.println("Male can eat Food");
	}
	void getInfo()
	{
		String name = "Charan";
		System.out.println("I am :"+name);
	}
}
class Female extends HumanDemo
{
	void eats()
	{
		System.out.println("FeMale can eat Food");
	}
	void getInfo()
	{
		String name = "Urmila";
		System.out.println("I am :"+name);
	}
}
public class HeirarchielDemo {

	public static void main(String[] args) {
		Female f=new Female();
		f.eats();
		f.getInfo();
		Male m=new Male();
		m.eats();
		m.getInfo();
				

	}

}
