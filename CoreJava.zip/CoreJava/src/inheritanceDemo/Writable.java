package inheritanceDemo;

public interface Writable {
	void write() ;
		
	

}
