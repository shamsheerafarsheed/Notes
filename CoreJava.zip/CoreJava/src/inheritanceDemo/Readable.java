package inheritanceDemo;
//interface is an absreact type used to define for classess to implement
//implements
//it sepecify set of abstract methods(method doesnt have body)and constants that implementing classes
public interface Readable {
	//abstract method(doent have body)
void reads() ;
	



}
