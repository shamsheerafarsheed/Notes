package Date_Number_CurrencyDemo;

import java.text.NumberFormat;
import java.util.Locale;

public class NumberFormattingDemo {

	public static void main(String[] args) {
		double number=2345678.89;
		NumberFormat formatter=NumberFormat.getNumberInstance(Locale.US);
		String FormattedNumber=formatter.format(number);
		System.out.println("Formatted Number is:"+FormattedNumber);
	}

}
