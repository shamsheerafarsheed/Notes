package AccessModifier2;

import DataTypesDemo.Message;


public class CallMessage extends Message{

	public static void main(String[] args) {
		//ProtectedDemo obj=new ProtectedDemo();
		CallMessage obj=new CallMessage();
		
		obj.show();//calling method
		//protected access modifier is accessible outside the package if it is subclass

	}

}
