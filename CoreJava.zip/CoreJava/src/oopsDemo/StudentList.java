package oopsDemo;
//Student is encapsulated class
public class StudentList {
	
private int sid;
private String name;
private String dept;
//setter and getter
public int getSid() {
	return sid;
}
public void setSid(int sid) {
	this.sid = sid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDept() {
	return dept;
}
public void setDept(String dept) {
	this.dept = dept;
}

}
