package oopsDemo;
class polygon
{
	//method to render a shape of polygon
	public void render()
	{
		System.out.println("Rendering a polygon");
	}
}
class hexagon extends polygon
{
	public void render()
	{
		System.out.println("Rendering a hexagon");
	}
}
class octagon extends polygon
{
	public void render()
	{
		System.out.println("Rendering a octogon");
	}
}
public class OverridingDemo {

	public static void main(String[] args) {
		hexagon h=new hexagon();
		h.render();
		
		octagon o=new octagon();
		o.render();
	}

}
