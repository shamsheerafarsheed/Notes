package oopsDemo;

public abstract class Payment {
abstract  void makepayment(double amount);
}
class CreditPayment extends Payment
{

	@Override
	void makepayment(double amount) {
		System.out.println("Paid rs"+amount+"Using Credit card");
		
	}}
class UPIPayment extends Payment
	{

		@Override
		void makepayment(double amount) {
			System.out.println("Paid rs"+amount+"Using UPI");
			
		}}
class NetBanking extends Payment
		{

			@Override
			void makepayment(double amount) {
				System.out.println("Paid rs"+amount+"Using NetBanking");
				
			}}
	

	

	

