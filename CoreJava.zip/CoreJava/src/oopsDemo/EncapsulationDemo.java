package oopsDemo;
/*
 * Encapsulation:provide control over the data
   Wrapping up of data and method into a single unit
   can make radable or writable
it has private data members and getter setter method.
 */
public class EncapsulationDemo {
	//private data members
	private String empname;
	/*//getter method-->to make private var readable
	public  String getEmpname()
	{
		return empname;
	}
//setter method-->write the data
	public void setEmpname()
	{
		this.empname=empname;
	}*/
	//getter setter method
	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public static void main(String[] args) {
		EncapsulationDemo ed=new EncapsulationDemo();
				//Setting the value in empname
				ed.setEmpname("Anushka"); 
		//getting value using getter method
		System.out.println(ed.getEmpname());
	}

	
}
