package oopsDemo;

public class PaymentApp {

	public static void main(String[] args) {
		Payment payment;//create reference object
		payment =new CreditPayment();
		payment.makepayment(2500);
		payment=new UPIPayment();
		payment.makepayment(1500);
		payment =new NetBanking ();
		payment.makepayment(3000);
		
		

	}

}
