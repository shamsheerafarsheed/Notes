package oopsDemo;
//abstract class
abstract class Animal
{
	//normal method
	void sound()
	{
		System.out.println("Animal makes sound");
	}
	//abstarct method
	abstract void eat();
} 
class Tiger extends Animal
{

	@Override
	void eat() {
		System.out.println("Will eat Flesh of Animal");
		
	}
	void sound()
	{
		System.out.println("Tiger makes sound:GRRR");
	}
	
}
class Elephant extends Animal
{

	@Override
	void eat() {
		System.out.println("Will eat sugarcanes ");
		
	}
	void sound()
	{
		System.out.println("Tiger makes sound:AHH");
	}
	
}

public class AbstarctDemo {

	public static void main(String[] args) {
		//Animal a=new Animal();we cant create object of an abstract class
		Tiger t=new Tiger();
		t.eat();
		t.sound();
		Elephant e=new Elephant();
		e.eat();
		e.sound();
		

	}

}

