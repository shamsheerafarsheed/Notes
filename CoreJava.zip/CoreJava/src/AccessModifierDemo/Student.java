package AccessModifierDemo;
/*Assignment-1.
● Create a class Student in Student.java then add member variables
studentName, collegeName of type String
● Add a member variable studentID of type int.
● Make all the member variables as private.
● Add a main method. And print a message “Successful”.
● Compile the class
● Run the class
 * 
 */

public class Student {
	//member var
	private String studentName="Aisha";;
	private  String collegeName;
	private int studentID;

	public static void main(String[] args) {
		 Student s1=new Student();
		 
			System.out.println("Successfulll");
			System.out.println(s1.studentName);
			
			
			
	}

}
