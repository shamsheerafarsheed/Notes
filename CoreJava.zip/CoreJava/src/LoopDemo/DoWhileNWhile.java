package LoopDemo;

public class DoWhileNWhile {

	public static void main(String[] args) {
		int num=10;
		while(num<5)
		{
			System.out.println(num);
			num++;//num+1
		}
		//do while
		int x=10;
		do
		{
			System.out.println(x);
			x++;//num+1
		}while(x<5);

	}

}
