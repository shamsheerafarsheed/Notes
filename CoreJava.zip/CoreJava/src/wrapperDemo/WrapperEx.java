package wrapperDemo;

public class WrapperEx {

	public static void main(String[] args) {
		// primitive to object(auto-boxing
		int num=10;
		Integer obj=Integer.valueOf(num);//explicit boxing
		Integer obj2=num;//auto-boxing
		System.out.println("Wrapped Integer:"+obj);
		System.out.println("Autoboxed Integer:"+obj2);
	
//object-->primitive(unboxing)
		int num1=obj.intValue();//explicit unboxing
		
		int num2=obj2;//auto-unboxing
		System.out.println("unboxed Int:"+num1);
		System.out.println("aoto-unboxed Integer:"+num2);
		
	}

}
