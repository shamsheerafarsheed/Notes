package VariableDemo;
class Learner
{
	//Static var
	public  static String name;
	public  static int age;
}
public class StaticVar {

	public static void main(String[] args) {
		Learner.name="Bipasha";
		System.out.println(Learner.name);

	}

}
