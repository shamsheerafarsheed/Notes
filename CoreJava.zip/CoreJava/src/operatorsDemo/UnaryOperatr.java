package operatorsDemo;
//++,---->only 1 operand
public class UnaryOperatr {

	public static void main(String[] args) {
		int num=12;
		
		
		System.out.println(num);
		++num;//preincrement1+num=13
		System.out.println(num);
		num++;//post increment13+1
		System.out.println(num);

	}

}
