package operatorsDemo;
//+,-,%,/,*
public class ArithmeticDemo {

	public static void main(String[] args) {
		float x=6.8f;
		float y=12.34f;
		System.out.println(x+y);

	}

}
