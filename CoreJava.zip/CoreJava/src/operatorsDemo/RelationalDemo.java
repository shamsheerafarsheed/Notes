package operatorsDemo;

public class RelationalDemo {

	public static void main(String[] args) {
		// (==,<=,>=,!=)
		int m=12;
		int n=54,s=12;
		boolean res1=m>=n;
		System.out.println(res1);
		boolean res2=m<=n;
		System.out.println(res2);
		boolean res3=m==s;
		System.out.println(res3);
		boolean res4=m!=n;
		System.out.println(res4);
				

	}

}
