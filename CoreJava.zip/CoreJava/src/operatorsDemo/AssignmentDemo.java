package operatorsDemo;

public class AssignmentDemo {

	public static void main(String[] args) {
		int x=12;
		System.out.println("x:"+x);
		int y=20;
		System.out.println("y:"+y);
y=x;
System.out.println("After assigning y:"+y);
	}

}
