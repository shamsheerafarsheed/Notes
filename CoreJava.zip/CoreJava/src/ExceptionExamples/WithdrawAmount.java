package ExceptionExamples;
//InsufficientFundException is a user defined exception so we should inherit from Exception class
class InsufficientFundException extends Exception
{
	private double amount;
	//parameterised constructor
	InsufficientFundException(double amount)
	{
		this.amount=amount;
	}
	//getter method to get amount
	public double getAmount()
	{
		return amount;
		
	}
	
}
class checkingAccount
{
	private double balance;
	private int number;
	//constructor
	checkingAccount(int number)
	{
		this.number=number;
	}
	//method to deposit amount
	public void Deposite(double amount)
	{
		balance+=amount;
	}
	//method to withdraw
	public void Withdraw(double amount)throws InsufficientFundException
	{
		if(amount<=balance)
		{
			balance-=amount;
		}
		else
		{
			double needs=amount=balance;
			throw new InsufficientFundException(needs);
		}
	}
}
public class WithdrawAmount {

	public static void main(String[] args) {
		checkingAccount ca=new checkingAccount(101);
		System.out.println("Depositing 10000Rs");
		ca.Deposite(10000);
		System.out.println("Depositing 1000Rs");
		ca.Deposite(1000);
		try
		{
			System.out.println("Withdrawing 5000");
			ca.Withdraw(5000);
			System.out.println("Withdrawing 7000");
			ca.Withdraw(7000);
		}
		catch(InsufficientFundException e)
		{
			System.out.println("You have no sufficient balance to withdraw:"+e.getAmount());
		}

	}

}
