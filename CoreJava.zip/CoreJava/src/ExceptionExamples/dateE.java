package ExceptionExamples;
import java.text.NumberFormat;
import java.util.Locale;
public class dateE {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		 double amount = 1234.56;

	        NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(Locale.US);
	        String formattedCurrency = currencyFormatter.format(amount);
	        System.out.println("Formatted Currency (US): " + formattedCurrency);

	        // For India
	        NumberFormat indiaCurrencyFormatter = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
	        System.out.println("Formatted Currency (India): " + indiaCurrencyFormatter.format(amount));
    
	}

}
