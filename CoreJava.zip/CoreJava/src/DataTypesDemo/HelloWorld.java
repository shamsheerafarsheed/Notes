package DataTypesDemo;


//creating helloword program
/*
 * multiline comment
 */
/**
 * Documental
 */
public class HelloWorld {
	
public int a=2;
	public static void main(String[] args) {
		int age=20;
		String name="Anusha";
		
System.out.println("Good Evening Students...");
System.out.println(age);
System.out.println(name);



	}

}
