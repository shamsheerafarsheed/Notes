package DataTypesDemo;
class ProtectedDemo
{
	//constructor
	protected ProtectedDemo()
	{
		System.out.println("This is a Protected constructor");
	}
}
public class Message {
//protected var
	//member variable
	protected int num1=10,num2=3;
	//method definition
	protected void show()
	{
		System.out.println("This is a Protected method");
	}
	public static void main(String[] args) {
		ProtectedDemo obj=new ProtectedDemo();
		Message obj1=new Message();
		obj1.show();//calling method

	}

}
