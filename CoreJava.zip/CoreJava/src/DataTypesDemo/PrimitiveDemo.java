package DataTypesDemo;
//default class
class A
{
	public String name_City="banglore";
	protected void show()
	{
		
	}
}

public class PrimitiveDemo {

	public static void main(String[] args) {
	short number=121;
	long number1=7463588748l;
	float num=54647.89f;
	double num1=478.890d;
	char letter='A';
	boolean flag=true;
	System.out.println(number);
	System.out.println(number1);
	System.out.println(letter);
	System.out.println(flag);

	}

}
