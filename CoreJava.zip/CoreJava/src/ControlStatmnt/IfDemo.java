package ControlStatmnt;

public class IfDemo {

	public static void main(String[] args) {
		int age=20;
		if(age>18)
		{
			System.out.println("eligible for vote");
		}
	}

}
