package ControlStatmnt;
 
public class ifelseDemo {

	public static void main(String[] args) {
		// checking number is even or odd
		int number=11;
		if(number % 2==0)
		{
			System.out.println("number is even");
		}
		else
		{
			System.out.println("odd number");
		}

	}

}
